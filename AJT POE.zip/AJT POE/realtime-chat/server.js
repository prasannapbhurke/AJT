const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve the frontend
app.use(express.static("public"));

// Runs when a user connects
io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    // Receive a message from a client
    socket.on("chat message", (message) => {
        console.log("Message:", message);
        // Send the message to all connected clients
        io.emit("chat message", message);
    });

    // Runs when a user disconnects
    socket.on("disconnect", () => {
        console.log("User disconnected:", socket.id);
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
