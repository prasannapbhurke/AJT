@echo off
title Real-Time Chat Server
echo Starting Real-Time Chat Server on http://localhost:3000...
node server.js
pause
