<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Form Result</title>
</head>
<body>

    <h2>Student Details</h2>

    <%
        String name = request.getParameter("username");
        String course = request.getParameter("course");
        int age = Integer.parseInt(request.getParameter("age"));
    %>

    Name: <%= name %> <br><br>
    Age: <%= age %> <br><br>
    Course: <%= course %> <br><br>

    <%
        if(age >= 18) {
    %>
        <h3>You are eligible.</h3>
    <%
        } else {
    %>
        <h3>You are not eligible.</h3>
    <%
        }
    %>

</body>
</html>