<!DOCTYPE html>
<html>
<head>
    <title>Student Form</title>
</head>
<body>
    <h2>Student Registration Form</h2>

    <form action="result.jsp" method="post">

        Name:
        <input type="text" name="username" required>
        <br><br>

        Age:
        <input type="number" name="age" required>
        <br><br>

        Course:
        <input type="text" name="course" required>
        <br><br>

        <input type="submit" value="Submit">

    </form>
</body>
</html>